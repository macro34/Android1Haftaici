package com.serifgungor.customspinner.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Spinner;

import com.serifgungor.customspinner.Adapter.CustomAdapter;
import com.serifgungor.customspinner.R;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    CustomAdapter adapter;
    int[] bayraklar = {R.drawable.tr,R.drawable.in};
    String[] ulkeler = {"Türkiye Cumhuriyeti","Hindistan"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new CustomAdapter(this,bayraklar,ulkeler);
        spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
    }
}
