package com.serifgungor.adsoyadyasornegi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    //GLOBAL ALAN
    EditText etAd,etSoyad,etYas,etSonuc;
    Button btnIslem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //NESNE REFERANSLARI TANIMLANMASI
        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
        etYas = findViewById(R.id.etYas);
        etSonuc = findViewById(R.id.etSonuc);
        btnIslem = findViewById(R.id.btnIslem);

        //BUTONUN TIKLAMA OLAYI
        btnIslem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ad = etAd.getText().toString();
                String soyad = etSoyad.getText().toString();
                String yas = etYas.getText().toString();
                /*
                getText().toString() ile edittext nesnesi içerisindeki o anda
                yazılmış yazıyı yakalayabiliriz.
                 */

                //etSonuc.setText(ad+" "+soyad+" "+yas);

                /*
                setText() ile edittext nesnesi içerisine yazı göndermeye yarar.
                 */

                if(Integer.parseInt(yas)>10){
                    etSonuc.setText("Yaşınız 10'dan büyük");
                }else{
                    etSonuc.setText("Yaşınız 10'dan küçük");
                }

            }
        });
    }
}
