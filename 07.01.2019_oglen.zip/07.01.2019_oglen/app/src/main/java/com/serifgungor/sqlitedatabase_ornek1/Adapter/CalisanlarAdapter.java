package com.serifgungor.sqlitedatabase_ornek1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.serifgungor.sqlitedatabase_ornek1.Model.Calisan;
import com.serifgungor.sqlitedatabase_ornek1.R;

import java.util.ArrayList;

public class CalisanlarAdapter extends BaseAdapter {
    Context context;
    ArrayList<Calisan> calisanlar;
    LayoutInflater layoutInflater;

    public CalisanlarAdapter(Context context,ArrayList<Calisan> calisanlar){
        this.calisanlar = calisanlar;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return calisanlar.size();
    }

    @Override
    public Object getItem(int position) {
        return calisanlar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.custom_person,null);

        TextView tvAdSoyad,tvTelNo,tvIseGiris;

        tvAdSoyad = v.findViewById(R.id.tvAdSoyad);
        tvIseGiris = v.findViewById(R.id.tvIseGirisTarihi);
        tvTelNo = v.findViewById(R.id.tvTelNo);

        tvAdSoyad.setText(calisanlar.get(position).getAdSoyad());
        tvIseGiris.setText(""+calisanlar.get(position).getIseGirisTarihi());
        tvTelNo.setText(""+calisanlar.get(position).getTelefonNo());

        return v;
    }
}
