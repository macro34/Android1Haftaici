package com.serifgungor.sqlitedatabase_ornek1.Activity;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.serifgungor.sqlitedatabase_ornek1.Adapter.CalisanlarAdapter;
import com.serifgungor.sqlitedatabase_ornek1.Database.DatabaseHelper;
import com.serifgungor.sqlitedatabase_ornek1.Model.Calisan;
import com.serifgungor.sqlitedatabase_ornek1.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnEkle,btnListele;
    ListView listView;
    DatabaseHelper databaseHelper;
    ArrayList<Calisan> calisanlar;
    CalisanlarAdapter adapter;

    public void calisanEkleDialog(){
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog_calisanekle);

        final EditText etAdSoyad = dialog.findViewById(R.id.etAdSoyad);
        final EditText etIseGiris = dialog.findViewById(R.id.etIseGiris);
        final EditText etTelNo = dialog.findViewById(R.id.etTelNo);
        final EditText etAdres = dialog.findViewById(R.id.etAdres);
        Button btnKaydet = dialog.findViewById(R.id.btnKaydet);
        btnKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String adSoyad,String iseGirisTarihi, String adres, String telefonNo
                databaseHelper.calisanEkle(etAdSoyad.getText().toString(),etIseGiris.getText().toString(),etAdres.getText().toString(),etTelNo.getText().toString());
                //Dialoğu kapat
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listViewCalisanlar);
        btnEkle = findViewById(R.id.btnEkle);
        btnListele = findViewById(R.id.btnListele);
        btnEkle.setOnClickListener(this);
        btnListele.setOnClickListener(this);

        //Veritabanı yardımcı sınıfı çağırdık
        databaseHelper = new DatabaseHelper(getApplicationContext(),"myDB");
        //Arraylist içerisine değerleri databaseHelper'dan çağırdık
        calisanlar = databaseHelper.calisanListele();

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.btnEkle){
            calisanEkleDialog();
        }else if(v.getId()==R.id.btnListele){
            //adapter'a verileri arraylist çalışanlardan aldık
            adapter = new CalisanlarAdapter(getApplicationContext(),calisanlar);
            //Listview'a verileri veritabanından yüklemiş olduk
            listView.setAdapter(adapter);
        }
    }
}
