package com.example.lab08.baseadapter_gridviewkullanimi2.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.example.lab08.baseadapter_gridviewkullanimi2.Adapter.KategoriAdapter;
import com.example.lab08.baseadapter_gridviewkullanimi2.Model.Kategori;
import com.example.lab08.baseadapter_gridviewkullanimi2.R;

import java.util.ArrayList;

public class FragmentKategoriler extends Fragment {

    KategoriAdapter adapter;
    ArrayList<Kategori> kategoriler = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_kategoriler, null);

        GridView gridViewKategoriler = v.findViewById(R.id.gridViewKategoriler);


        kategoriler.add(new Kategori(1, "Çizgi Roman", R.drawable.cizgi_romann));
        kategoriler.add(new Kategori(1, "Hikaye", R.drawable.cizgi_romann));
        kategoriler.add(new Kategori(1, "Dini", R.drawable.cizgi_romann));
        kategoriler.add(new Kategori(1, "Kişisel Gelişim", R.drawable.cizgi_romann));
        kategoriler.add(new Kategori(1, "Roman", R.drawable.cizgi_romann));
        kategoriler.add(new Kategori(1, "Tarihi", R.drawable.cizgi_romann));
        kategoriler.add(new Kategori(1, "Şiir", R.drawable.cizgi_romann));

        adapter = new KategoriAdapter(kategoriler, getContext());
        gridViewKategoriler.setAdapter(adapter);


        return v;
    }
}