package com.example.lab08.baseadapter_gridviewkullanimi2.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.example.lab08.baseadapter_gridviewkullanimi2.Adapter.YeniKitaplarAdapter;
import com.example.lab08.baseadapter_gridviewkullanimi2.Model.Kitap;
import com.example.lab08.baseadapter_gridviewkullanimi2.R;

import java.util.ArrayList;


public class FragmentAnasayfa extends Fragment {

    YeniKitaplarAdapter adapter;
    ArrayList<Kitap> kitaplar = new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_anasayfa, null);

        GridView gridView = v.findViewById(R.id.gridViewYeniKitaplar);

        /*
        Kitap kitap = new Kitap();
        kitap.setAd("Kitap Adı");
        kitap.setAciklama("Açıklama");
        kitap.setIlkBasimYili(2016);
        kitap.setKategori("Kategori");
        kitap.setResim("R.drawable.cardview_bg_01");
        kitap.setSayfaSayisi(333);
        kitap.setYayinEvi("Ulak Yayıncılık");
        kitap.setYazarAdSoyad("Ergün Hiçyılmaz");
        */

        /*
        (int kitapId, String ad, String kategori, String yazarAdSoyad,
                 String yayinEvi, String aciklama, int sayfaSayisi, int ilkBasimYili, int resim)
         */

        kitaplar.add(new Kitap(1, "Kitap 1", "Kategori1",
                "Yazar", "YayınEvi", "Açıklama", 200, 2017, R.drawable.cardview_bg_01));
        kitaplar.add(new Kitap(2, "Kitap 2", "Kategori2",
                "Yazar", "YayınEvi", "Açıklama", 200, 2017, R.drawable.cardview_bg_02));
        kitaplar.add(new Kitap(3, "Kitap 3", "Kategori3",
                "Yazar", "YayınEvi", "Açıklama", 200, 2017, R.drawable.cardview_bg_03));
        kitaplar.add(new Kitap(4, "Kitap 4", "Kategori4",
                "Yazar", "YayınEvi", "Açıklama", 200, 2017, R.drawable.cardview_bg_04));
        kitaplar.add(new Kitap(5, "Kitap 5", "Kategori5",
                "Yazar", "YayınEvi", "Açıklama", 200, 2017, R.drawable.cardview_bg_05));

        adapter = new YeniKitaplarAdapter(kitaplar, getContext());
        gridView.setAdapter(adapter);


        return v;
    }
}
