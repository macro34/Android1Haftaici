package com.example.lab08.baseadapter_gridviewkullanimi2.Model;

import java.io.Serializable;

public class Kitap implements Serializable {

    private int kitapId;
    private String ad;
    private String kategori;
    private String yazarAdSoyad;
    private String yayinEvi;
    private String aciklama;
    private int sayfaSayisi;
    private int ilkBasimYili;
    private int resim;

    public Kitap() {
    }

    public Kitap(int kitapId, String ad, String kategori, String yazarAdSoyad,
                 String yayinEvi, String aciklama, int sayfaSayisi, int ilkBasimYili, int resim) {
        this.kitapId = kitapId;
        this.ad = ad;
        this.kategori = kategori;
        this.yazarAdSoyad = yazarAdSoyad;
        this.yayinEvi = yayinEvi;
        this.aciklama = aciklama;
        this.sayfaSayisi = sayfaSayisi;
        this.ilkBasimYili = ilkBasimYili;
        this.resim = resim;
    }

    public int getKitapId() {
        return kitapId;
    }

    public void setKitapId(int kitapId) {
        this.kitapId = kitapId;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getYazarAdSoyad() {
        return yazarAdSoyad;
    }

    public void setYazarAdSoyad(String yazarAdSoyad) {
        this.yazarAdSoyad = yazarAdSoyad;
    }

    public String getYayinEvi() {
        return yayinEvi;
    }

    public void setYayinEvi(String yayinEvi) {
        this.yayinEvi = yayinEvi;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public int getSayfaSayisi() {
        return sayfaSayisi;
    }

    public void setSayfaSayisi(int sayfaSayisi) {
        this.sayfaSayisi = sayfaSayisi;
    }

    public int getIlkBasimYili() {
        return ilkBasimYili;
    }

    public void setIlkBasimYili(int ilkBasimYili) {
        this.ilkBasimYili = ilkBasimYili;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}
