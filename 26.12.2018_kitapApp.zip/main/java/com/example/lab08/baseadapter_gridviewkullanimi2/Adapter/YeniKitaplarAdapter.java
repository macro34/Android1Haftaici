package com.example.lab08.baseadapter_gridviewkullanimi2.Adapter;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.lab08.baseadapter_gridviewkullanimi2.Model.Kitap;
import com.example.lab08.baseadapter_gridviewkullanimi2.R;

import java.util.ArrayList;

public class YeniKitaplarAdapter extends BaseAdapter {

    ArrayList<Kitap> kitaplar;
    Context context;
    LayoutInflater layoutInflater;

    public YeniKitaplarAdapter(ArrayList<Kitap> kitaplar, Context context) {
        this.kitaplar = kitaplar;
        this.context = context;
        this.layoutInflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return kitaplar.size();
    }

    @Override
    public Object getItem(int position) {
        return kitaplar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.custom_gridview_yenikitap, null);

        CardView cardView = v.findViewById(R.id.cardViewYeniKitaplar);
        TextView textView = v.findViewById(R.id.tvYeniKitapBaslik);


        cardView.setBackgroundResource(kitaplar.get(position).getResim());
        textView.setText("" + kitaplar.get(position).getAd());

        return v;
    }
}
