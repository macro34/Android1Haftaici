package com.example.lab08.baseadapter_gridviewkullanimi2.Adapter;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lab08.baseadapter_gridviewkullanimi2.Model.Kategori;
import com.example.lab08.baseadapter_gridviewkullanimi2.R;

import java.util.ArrayList;

public class KategoriAdapter extends BaseAdapter {
    ArrayList<Kategori> kategoriler;
    Context context;
    LayoutInflater layoutInflater;


    public KategoriAdapter(ArrayList<Kategori> kategoriler, Context context) {
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.kategoriler = kategoriler;
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Object getItem(int i) {
        return kategoriler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        final View v = layoutInflater.inflate(R.layout.custom_gridview_kategori, null);

        CardView cardView = v.findViewById(R.id.cardViewKategori);
        TextView baslik = v.findViewById(R.id.tvKategoriBaslik);
        cardView.setBackgroundResource(kategoriler.get(i).getResim());
        baslik.setText(kategoriler.get(i).getAd());

        //Satıra tıklanma olayı
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(
                        v.getContext(),
                        kategoriler.get(i).getAd(),
                        Toast.LENGTH_LONG
                ).show();
            }
        });


        return v;
    }
}