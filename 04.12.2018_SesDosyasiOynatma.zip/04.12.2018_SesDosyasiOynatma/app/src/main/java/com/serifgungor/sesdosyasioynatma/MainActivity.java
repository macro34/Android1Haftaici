package com.serifgungor.sesdosyasioynatma;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    CardView cv1,cv2,cv3;
    MediaPlayer ses1,ses2,ses3;
    //http://www.hochmuth.com/mp3-samples.htma

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cv1 = findViewById(R.id.cardView1);
        cv2 = findViewById(R.id.cardView2);
        cv3 = findViewById(R.id.cardView3);

        ses1 = MediaPlayer.create(this,R.raw.deneme);
        ses2 = MediaPlayer.create(this,R.raw.deneme2);
        ses3 = MediaPlayer.create(this,R.raw.deneme3);

        cv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ses1.isPlaying()){
                    ses1.start();
                }else {
                    ses1.pause();
                }
            }
        });

        cv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ses2.isPlaying()){
                    ses2.start();
                }else {
                    ses2.pause();
                }
            }
        });

        cv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ses3.isPlaying()){
                    ses3.start();
                }else {
                    ses3.pause();
                }
            }
        });




    }
}
