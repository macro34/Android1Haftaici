package com.serifgungor.pdf_goruntuleyici_eduapp.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.serifgungor.pdf_goruntuleyici_eduapp.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Beklet().start();
        //Thread sınıfının run metodunu tetikler
    }

    private class Beklet extends Thread{

        @Override
        public void run() {
            //Thread sınıfının çalışma zamanını temsil eder.
            super.run();

            try {
                Thread.sleep(5000); //5 saniye bekle
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent); // Diğer sayfayı aç
            finish(); // Bulunduğum sayfayı kalıcı olarak kapatır.

        }
    }
}
