package com.serifgungor.pdf_goruntuleyici_eduapp.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.serifgungor.pdf_goruntuleyici_eduapp.Fragment.FragmentBaslangic;
import com.serifgungor.pdf_goruntuleyici_eduapp.Fragment.FragmentOrta;

public class TabFragmentAdapter extends FragmentStatePagerAdapter {

    private int tabSayisi;
    private FragmentManager fm;

    public TabFragmentAdapter(FragmentManager fm,int tabSayisi){
        super(fm);
        this.tabSayisi = tabSayisi;
        this.fm = fm;
    }


    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        if(position==0){
            fragment = new FragmentBaslangic();
        }else if(position==1){
            fragment = new FragmentOrta();
        }else{
            fragment = new FragmentBaslangic();
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return tabSayisi;
    }
}
