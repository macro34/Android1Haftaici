package com.serifgungor.pdf_goruntuleyici_eduapp.Activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.serifgungor.pdf_goruntuleyici_eduapp.R;

public class MainActivity extends AppCompatActivity {

    Button btnGiris,btnOyVer,btnSoruSor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGiris = findViewById(R.id.btnGiris);
        btnOyVer = findViewById(R.id.btnOyVer);
        btnSoruSor = findViewById(R.id.btnSoruSor);


        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),KonularActivity.class);
                startActivity(intent);
                //MainActivity sınıfı, KonularActivity sayfasını açar.
            }
        });

        btnOyVer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+getPackageName())));
                }catch (ActivityNotFoundException e){
                    Toast.makeText(getApplicationContext(),"Hay aksi!/nBu uygulamayı açabilen program yüklü değil",Toast.LENGTH_LONG).show();
                }

            }
        });

        btnSoruSor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "contact@serifgungor.com" });
                intent.putExtra(Intent.EXTRA_SUBJECT, "Android Intent Örneği");
                intent.putExtra(Intent.EXTRA_TEXT, "Hocam kusura bakma, örneği deniyordum :)");
                startActivity(Intent.createChooser(intent, "E-mail gönder"));

            }
        });
    }
}
