package com.serifgungor.intentkullanimiornek2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etSayi1,etSayi2;
    Button btnTopla,btnCikar,btnCarp,btnBol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etSayi1 = findViewById(R.id.etSayi1);
        etSayi2 = findViewById(R.id.etSayi2);
        btnTopla = findViewById(R.id.btnTopla);
        btnCikar = findViewById(R.id.btnCikarma);
        btnCarp = findViewById(R.id.btnCarpma);
        btnBol = findViewById(R.id.btnBolme);
        btnBol.setOnClickListener(this);
        btnCarp.setOnClickListener(this);
        btnCikar.setOnClickListener(this);
        btnTopla.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(getApplicationContext(),SonucActivity.class);
        int sayi1 = Integer.parseInt(etSayi1.getText().toString());
        int sayi2 = Integer.parseInt(etSayi2.getText().toString());
        i.putExtra("sayi1",sayi1);
        i.putExtra("sayi2",sayi2);
        switch (v.getId()){
            case R.id.btnBolme:
                i.putExtra("islem",btnBol.getText());
                i.putExtra("sonuc",(sayi1/sayi2));
                break;
            case R.id.btnTopla:
                i.putExtra("islem",btnTopla.getText());
                i.putExtra("sonuc",(sayi1+sayi2));
                break;
            case R.id.btnCarpma:
                i.putExtra("islem",btnCarp.getText());
                i.putExtra("sonuc",(sayi1*sayi2));
                break;
            case R.id.btnCikarma:
                i.putExtra("islem",btnCikar.getText());
                i.putExtra("sonuc",(sayi1-sayi2));
                break;
        }
        startActivity(i);
    }
}
