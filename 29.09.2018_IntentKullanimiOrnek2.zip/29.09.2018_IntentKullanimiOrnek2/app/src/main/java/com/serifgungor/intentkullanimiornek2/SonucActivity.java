package com.serifgungor.intentkullanimiornek2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SonucActivity extends AppCompatActivity {

    TextView tvSayi1,tvSayi2,tvSonuc,tvIslem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonuc);

        tvIslem = findViewById(R.id.tvIslem);
        tvSonuc = findViewById(R.id.tvSonuc);
        tvSayi2 = findViewById(R.id.tvSayi2);
        tvSayi1 = findViewById(R.id.tvSayi1);
    }
}
