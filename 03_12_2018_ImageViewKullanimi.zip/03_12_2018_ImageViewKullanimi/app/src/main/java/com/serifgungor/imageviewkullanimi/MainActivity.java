package com.serifgungor.imageviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnIstanbul,btnBogazici,btnIstanbulTicaret,btnDumlupinar;
    ImageView ivResim;

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnBogazici:
                ivResim.setImageResource(R.drawable.bogazici_universitesi);
                break;
            case R.id.btnDumlupinar:
                ivResim.setImageResource(R.drawable.kutahya_dumlupinar_universitesi);
                break;
            case R.id.btnIstanbul:
                ivResim.setImageResource(R.drawable.istanbul_universitesi);
                break;
            case R.id.btnTicaret:
                ivResim.setImageResource(R.drawable.istanbul_ticaret_universitesi);
                break;
        }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivResim = findViewById(R.id.imageView);
        btnIstanbul = findViewById(R.id.btnIstanbul);
        btnBogazici = findViewById(R.id.btnBogazici);
        btnIstanbulTicaret = findViewById(R.id.btnBogazici);
        btnDumlupinar = findViewById(R.id.btnDumlupinar);

        btnIstanbul.setOnClickListener(this);
        btnBogazici.setOnClickListener(this);
        btnDumlupinar.setOnClickListener(this);
        btnIstanbulTicaret.setOnClickListener(this);



    }


}
