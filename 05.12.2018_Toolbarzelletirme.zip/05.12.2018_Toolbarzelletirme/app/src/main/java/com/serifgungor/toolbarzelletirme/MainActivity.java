package com.serifgungor.toolbarzelletirme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //toolbarı gizle
        //this.getSupportActionBar().hide();

        Toolbar toolbar = findViewById(R.id.toolbar);
        //Benim oluşturduğum toolbar'ı varsayılan olarak ata
        setSupportActionBar(toolbar);

        //Şuanda kullandığım action bar
        this.getSupportActionBar().setTitle("");
        TextView tvBaslik = toolbar.findViewById(R.id.textView);
        tvBaslik.setText("Custom Toolbar");


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /*
        XML Tarafındaki tanımlı bir menü klasörünü activity sınıfında
        çağırmak için kullanılır.
         */
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        /*
        Çağırılan menü içerisindeki bir elemana tıklanma olayını yakalar.
         */

        if(item.getItemId()==R.id.item_bagis){
            Toast.makeText(getApplicationContext(),"Bağış yapıldı",Toast.LENGTH_LONG).show();
        }else if(item.getItemId()==R.id.item_googleplay){
            Toast.makeText(getApplicationContext(),"Yorum yapıldı",Toast.LENGTH_LONG).show();
        }else if(item.getItemId()==R.id.item_iletisim){
            Toast.makeText(getApplicationContext(),"İletişim kuruldu",Toast.LENGTH_LONG).show();
        }

        return super.onOptionsItemSelected(item);
    }
}
