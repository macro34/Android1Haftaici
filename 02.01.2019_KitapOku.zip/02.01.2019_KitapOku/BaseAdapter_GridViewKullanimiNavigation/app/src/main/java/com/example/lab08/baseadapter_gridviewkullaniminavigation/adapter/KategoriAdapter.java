package com.example.lab08.baseadapter_gridviewkullaniminavigation.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lab08.baseadapter_gridviewkullaniminavigation.R;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.activity.KategoriKitaplarActivity;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kategori;

import java.util.ArrayList;

public class KategoriAdapter extends BaseAdapter {

    ArrayList<Kategori> kategoriler;
    Context context;
    LayoutInflater layoutInflater;

    public KategoriAdapter (ArrayList<Kategori> kategoriler, Context context) {
        this.context = context;
        this.layoutInflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.kategoriler = kategoriler;
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Object getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.custom_gridview_kategori, null);
        CardView cardView = v.findViewById(R.id.cardViewKategori);
        TextView textView = v.findViewById(R.id.tvKategoriBaslik);
        cardView.setBackgroundResource(kategoriler.get(position).getResim());
        textView.setText(kategoriler.get(position).getAd());

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                Toast.makeText(
                        v.getContext(),
                        kategoriler.get(position).getAd(),
                        Toast.LENGTH_LONG
                ).show();
                */

                Intent intent = new Intent(v.getContext(), KategoriKitaplarActivity.class);
                intent.putExtra("kategori", kategoriler.get(position));
                v.getContext().startActivity(intent);


            }
        });


        return v;
    }
}
