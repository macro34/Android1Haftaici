package com.example.lab08.baseadapter_gridviewkullaniminavigation.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.example.lab08.baseadapter_gridviewkullaniminavigation.R;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.adapter.YeniKitaplarAdapter;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kitap;

import java.util.ArrayList;

public class FragmentAnasayfa extends Fragment {

    YeniKitaplarAdapter adapter;
    ArrayList<Kitap> kitaplar = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_anasayfa, null);

        GridView gridView = v.findViewById(R.id.gridViewYeniKitaplar);

        Kitap kitap = new Kitap();
        kitap.setAd("Kitap Adi");
        kitap.setAciklama("Aciklama");
        kitap.setIlkBasimYili(2018);
        kitap.setKategori("Kategori");
        kitap.setKitapId(1);
        kitap.setResim(R.drawable.cardview_bg_01);
        kitap.setSayfaSayisi(300);
        kitap.setYayinEvi("Yayin Evi");
        kitap.setYazarAdSoyad("Yazar Ad Soyad");

        //int kitapId, String ad, String kategori, String yazarAdSoyad, String yayinEvi, String aciklama,
        //int sayfaSayisi, int ilkBasimYili, int resim

        Kitap kitap1 = new Kitap(2, "Kitap", "Kategori", "Yazar Ad Soyad", "Yayin Evi",
                "Aciklama", 300, 2018, R.drawable.cardview_bg_02);

        kitaplar.add(new Kitap(1, "Kitap1", "Kategori1", "Yazar Ad Soyad 1",
                "Yayin Evi 1", "Aciklama 1", 100, 2018, R.drawable.cardview_bg_01));
        kitaplar.add(new Kitap(2, "Kitap2", "Kategori2", "Yazar Ad Soyad 2",
                "Yayin Evi 2", "Aciklama 2", 200, 2017, R.drawable.cardview_bg_02));
        kitaplar.add(new Kitap(3, "Kitap3", "Kategori3", "Yazar Ad Soyad 3",
                "Yayin Evi 3", "Aciklama 3", 300, 2016, R.drawable.cardview_bg_03));
        kitaplar.add(new Kitap(4, "Kitap4", "Kategori4", "Yazar Ad Soyad 4",
                "Yayin Evi 4", "Aciklama 4", 400, 2015, R.drawable.cardview_bg_04));
        kitaplar.add(new Kitap(5, "Kitap5", "Kategori5", "Yazar Ad Soyad 5",
                "Yayin Evi 5", "Aciklama 5", 500, 2014, R.drawable.cardview_bg_05));


        adapter = new YeniKitaplarAdapter(kitaplar, getContext());
        gridView.setAdapter(adapter);



        return v;
    }
}
