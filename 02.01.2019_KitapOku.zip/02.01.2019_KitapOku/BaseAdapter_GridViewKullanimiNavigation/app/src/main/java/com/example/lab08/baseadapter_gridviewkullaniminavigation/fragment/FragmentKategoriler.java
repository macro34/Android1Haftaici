package com.example.lab08.baseadapter_gridviewkullaniminavigation.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.example.lab08.baseadapter_gridviewkullaniminavigation.R;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.adapter.KategoriAdapter;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kategori;

import java.util.ArrayList;

public class FragmentKategoriler extends Fragment {

    KategoriAdapter adapter;
    ArrayList<Kategori> kategoriler = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_kategoriler, null);
        GridView gridViewKategoriler = v.findViewById(R.id.gridViewKategoriler);

        kategoriler.add(new Kategori(1,"Cizgi Roman", R.drawable.kategori1));
        kategoriler.add(new Kategori(2,"Hikaye", R.drawable.kategori2));
        kategoriler.add(new Kategori(3,"Dini", R.drawable.kategori3));
        kategoriler.add(new Kategori(4,"Kisisel Gelisim", R.drawable.kategori4));
        kategoriler.add(new Kategori(5,"Roman", R.drawable.kategori5));
        kategoriler.add(new Kategori(6,"Tarihi", R.drawable.kategori6));
        kategoriler.add(new Kategori(7,"Siir", R.drawable.kategori7));

        adapter = new KategoriAdapter(kategoriler, getContext());
        gridViewKategoriler.setAdapter(adapter);
        return v;
    }
}
