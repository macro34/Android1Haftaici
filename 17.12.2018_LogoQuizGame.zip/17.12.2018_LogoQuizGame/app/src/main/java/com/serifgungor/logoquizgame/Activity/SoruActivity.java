package com.serifgungor.logoquizgame.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nex3z.flowlayout.FlowLayout;
import com.serifgungor.logoquizgame.Model.Sorular;
import com.serifgungor.logoquizgame.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SoruActivity extends AppCompatActivity {

    ImageView ivGoToBack,ivBack,ivNext,ivLogoPhoto;
    TextView tvTitle;
    FlowLayout flowLayout1,flowLayout2;
    Button btnIpucu,btnTemizle,btnGeriAl;
    int soru_indis;
    ArrayList<Sorular> sorular;



    String uretilenKelime="";
    //Kullanıcının verdiği yanıta göre üretilen yeni kelimenin değeri

    ArrayList<Integer> uretilenKelimeIndisler = new ArrayList<>();

    public void harfEkle(String c){
        //uretilenKelime değişkeninin değerini güncelledik.
        uretilenKelime += c;
    }

    public void soruHarfleriGetir(String kelime){
        for (int i=0; i<kelime.length(); i++){
            Button btn = new Button(this);
            btn.setId(i);
            btn.setBackgroundResource(R.drawable.custom_button_border);
            btn.setLayoutParams(new LinearLayout.LayoutParams(150,140));
            btn.setGravity(Gravity.CENTER);
            flowLayout1.addView(btn);
        }
    }

    public void degerleriTemizle(){
        try{
            flowLayout1.removeAllViews();
            flowLayout2.removeAllViews();
            uretilenKelime = "";
        }catch (Exception e){
        }
        // Yeni soruya geçmeden önce üretilen kutuları ilgil FlowLayout nesnelerinde sildik.
    }

    public void soruHarfleriGuncelle(String uretilenYeniKelime){
        Button b = findViewById(uretilenYeniKelime.length());
        b.setText("");
    }

    public String shuffle(String input){
        List<Character> characters = new ArrayList<Character>();
        for(char c:input.toCharArray()){
            characters.add(c);
        }
        StringBuilder output = new StringBuilder(input.length());
        while (characters.size()!=0){
            int randPicker = (int)(Math.random()*characters.size());
            output.append(characters.remove(randPicker));
        }
        return output.toString();
        // Argüman olarak gönderilen String değeri karıştırıp, yeni bir kelime olarak döndürür.
    }

    public void rastgeleHarfleriGetir(final String kelime){
        int uzunluk = kelime.length()*2;
        String harfler = "QWERTYUIOPĞÜASDFGHJKLŞİZXCVBNMÖÇ";
        String yeniKelime = "";
        for(int i=0; i<kelime.length(); i++){
            Random ran = new Random();
            int sayi = ran.nextInt(harfler.length());
            yeniKelime += harfler.charAt(sayi);
        }
        //Kelimenin uzunluğu kadar rastgele kelime ürettik.

        String sonUretilen = kelime+yeniKelime;
        String sonDeger = shuffle(sonUretilen);
        //Orinal kelime ve rastgele seçilen karakterleri sonUretilen içerisinde birleştirdik.
        // sonDeger string'i shuffle metodu sayesinde kelime ve yeniKelimeyi tekrar karıştırıp
        // yeni bir string haline çevirdi.

        for(int i=0; i<sonDeger.length(); i++){
            final Button btn = new Button(this);
            final int id = i+100;
            btn.setId(id);
            btn.setLayoutParams(new LinearLayout.LayoutParams(150,140));
            btn.setBackgroundResource(R.drawable.custom_button_border);
            btn.setText(""+sonDeger.charAt(i));
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
            flowLayout2.addView(btn);
        }
    }

    public void soruGetir(){
        //Kelimeye ait kutuları üretir.
        soruHarfleriGetir(sorular.get(soru_indis).getKelime());

        //Orijinal kelimeyi de içerisine dahil edip karmaşık sıralı harfleri flowLayout2
        //içerisine ekler
        rastgeleHarfleriGetir(sorular.get(soru_indis).getKelime());

        /*
        Bu uygulama paketi içerisinde drawable klasöründeki araba.png dosyasının
        referans adresi karşılığını öğrenmek istediğimiz zaman Identifier kavramına ihtiyaç duyarız.
        */
        int imgId = getResources().getIdentifier(
            sorular.get(soru_indis).getLogo_url(),
            "drawable",
            this.getPackageName()
        );
        ivLogoPhoto.setImageResource(imgId);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soru);
        this.getSupportActionBar().hide();

        sorular = new ArrayList<>();
        /*
int id, int seviye_id, String logo_url, String kelime, int puan, int cozuldu_mu
         */
        sorular.add(
                new Sorular(
                        1,1,"hp","HP",10,0
                )
        );
        sorular.add(
                new Sorular(
                        2,1,"ibb","İBB",10,0
                )
        );
        sorular.add(
                new Sorular(
                        3,1,"android","ANDROİD",10,0
                )
        );

        ivBack = findViewById(R.id.ivBack);
        ivGoToBack = findViewById(R.id.ivGoToBack);
        ivNext = findViewById(R.id.ivNext);
        ivLogoPhoto = findViewById(R.id.ivLogoPhoto);
        tvTitle = findViewById(R.id.tvTitle);
        flowLayout1 = findViewById(R.id.flowlayout1);
        flowLayout2 = findViewById(R.id.flowlayout2);
        btnGeriAl = findViewById(R.id.btnIpucu);
        btnTemizle = findViewById(R.id.btnTemizle);
        btnIpucu = findViewById(R.id.btnIpucu);

        soruHarfleriGetir(sorular.get(0).getKelime());
        rastgeleHarfleriGetir(sorular.get(0).getKelime());
        soruGetir();




        btnTemizle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnIpucu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnGeriAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(soru_indis>0){
                    soru_indis--;
                    degerleriTemizle();
                    soruGetir();
                }
                /*
                Geri al butonuna bastığımızda indise ait soruyu getirir.
                İlgili sorudan kullanıcının verdiği yanıta göre 1 karakter siler.
                 */
            }
        });

        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(soru_indis<sorular.size()-1){
                    soru_indis++;
                    degerleriTemizle();
                    soruGetir();
                }
                //Karşımıza yeni soru getirir.
                //yeni soru gelmeden önce değerleri temizleyerek, bir önceki sorudaki
                //butonları kaldırdık.
            }
        });

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(soru_indis>0){
                    soru_indis--;
                    degerleriTemizle();
                    soruGetir();
                }
            }
        });

    }
}
