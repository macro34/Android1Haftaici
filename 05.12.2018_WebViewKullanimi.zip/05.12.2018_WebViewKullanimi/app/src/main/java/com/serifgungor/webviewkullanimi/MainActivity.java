package com.serifgungor.webviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    WebViewClient webViewClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webView.loadUrl("https://serifgungor.com");
        // Web sayfasının adresini tanımladık
        webView.getSettings().setJavaScriptEnabled(true);
        // Bağlanılan web sayfasında JavaScript desteğini etkinleştirir.
        webView.getSettings().setSupportZoom(true);
        // Zoom Desteği
        webView.getSettings().setBuiltInZoomControls(true);
        // Zoom controller desteği ekler.

        /*
        WebViewClient sayesinde, ilgili tıklanan sayfayı yine aynı
        webView nesnesi içerisinde gösterdik.
         */
        webViewClient = new WebViewClient();
        webView.setWebViewClient(webViewClient);


    }
}
