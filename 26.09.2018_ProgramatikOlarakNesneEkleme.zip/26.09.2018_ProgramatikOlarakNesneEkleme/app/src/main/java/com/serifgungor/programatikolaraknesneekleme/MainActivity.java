package com.serifgungor.programatikolaraknesneekleme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    LinearLayout linearLayout;
    Button btn;

    public void butonEkle(int i){
        Button btn = new Button(this);
        btn.setText("Buton "+i);
        btn.setHeight(50);
        btn.setWidth(200);
        linearLayout.addView(btn);
    }

    public void yaziEkle(int i){
        TextView tv = new TextView(this);
        tv.setText("Yazı "+i);
        tv.setTextSize(16f);
        tv.setHeight(50);
        linearLayout.addView(tv);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        linearLayout = findViewById(R.id.linearLayout);
        btn = findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<20; i++){
                    if(i%2==0){
                        butonEkle(i);
                    }else{
                        yaziEkle(i);
                    }
                }

            }
        });


    }
}
