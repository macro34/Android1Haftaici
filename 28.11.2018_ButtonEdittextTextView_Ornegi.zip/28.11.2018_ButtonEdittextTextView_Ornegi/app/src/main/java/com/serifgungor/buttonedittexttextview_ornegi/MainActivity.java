package com.serifgungor.buttonedittexttextview_ornegi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //Global alan

    //Değişkenler (Field)
    EditText sayi1,sayi2;
    Button topla,cikar,carp,bol;
    TextView tvSonuc;
    int deger1,deger2,sonuc;

    /*
    1 - Değişken ismi sayı ile başlayamaz
    2 - İlk karakteri büyük harf olamaz
    3 - Türkçe karakter içermemelidir.
    4 - Boşluk bırakamayız. (Özel karakter içeremez; +-*
    5 - Yazılım diline ait rezerve(özel) kelimeler kullanılamaz.
    */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Hesaplama Örneği");
        //Activity sayfasının toolbarda görünen başlığını değiştirme

        //Nesne referansı tanımlama
        tvSonuc = findViewById(R.id.tvSonuc);
        sayi1 = findViewById(R.id.etSayi1);
        sayi2 = findViewById(R.id.etSayi2);
        topla = findViewById(R.id.btnTopla);
        cikar = findViewById(R.id.btnCikar);
        carp = findViewById(R.id.btnCarp);
        bol = findViewById(R.id.btnBol);

        //Nesnenin tıklama olayı - setOnClickListener
        topla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1+deger2;
                tvSonuc.setText("Toplama sonucu: "+sonuc);
            }
        });

        cikar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1-deger2;
                tvSonuc.setText("Çıkarma sonucu: "+sonuc);
            }
        });

        carp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1*deger2;
                tvSonuc.setText("Çarpma sonucu: "+sonuc);
            }
        });

        bol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1/deger2;
                tvSonuc.setText("Bölme sonucu: "+sonuc);
            }
        });


    }
}
