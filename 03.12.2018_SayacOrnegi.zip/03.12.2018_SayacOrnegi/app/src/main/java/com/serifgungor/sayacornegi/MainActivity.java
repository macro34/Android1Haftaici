package com.serifgungor.sayacornegi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvYazi,tvSayi;
    Button btnYazi,btnSay;
    int sayi=0;
    String[] yazilar = new String[5];
    int yaziIndis = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvYazi = findViewById(R.id.tvYazi);
        tvSayi = findViewById(R.id.tvSayac);
        btnYazi = findViewById(R.id.btnYazi);
        btnSay = findViewById(R.id.btnSay);

        yazilar[0]="Bir";
        yazilar[1]="Android";
        yazilar[2]="Eğitimine";
        yazilar[3]="Daha";
        yazilar[4]="Başladık !";
        btnYazi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvYazi.setText(yazilar[yaziIndis]);
                yaziIndis++;
                if(yaziIndis==5){
                    yaziIndis=0;
                }
            }
        });

        btnSay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSayi.setText(""+sayi);
                sayi++;
            }
        });


    }
}
