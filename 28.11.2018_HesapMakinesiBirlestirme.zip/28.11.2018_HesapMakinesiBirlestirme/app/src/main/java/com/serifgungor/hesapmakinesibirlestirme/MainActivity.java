package com.serifgungor.hesapmakinesibirlestirme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editText;

    public void butonaTikla(View view){
        if(view.getId()==R.id.btn0){
            editText.setText(editText.getText().toString()+"0");
        }else if(view.getId()==R.id.btn1){
            editText.setText(editText.getText().toString()+"1");
        }else if(view.getId()==R.id.btn2){
            editText.setText(editText.getText().toString()+"2");
        }else if(view.getId()==R.id.btn3){
            editText.setText(editText.getText().toString()+"3");
        }else if(view.getId()==R.id.btn4){
            editText.setText(editText.getText().toString()+"4");
        }else if(view.getId()==R.id.btn5){
            editText.setText(editText.getText().toString()+"5");
        }else if(view.getId()==R.id.btn6){
            editText.setText(editText.getText().toString()+"6");
        }else if(view.getId()==R.id.btn7){
            editText.setText(editText.getText().toString()+"7");
        }else if(view.getId()==R.id.btn8){
            editText.setText(editText.getText().toString()+"8");
        }else if(view.getId()==R.id.btn9){
            editText.setText(editText.getText().toString()+"9");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.etSayi);
    }
}
