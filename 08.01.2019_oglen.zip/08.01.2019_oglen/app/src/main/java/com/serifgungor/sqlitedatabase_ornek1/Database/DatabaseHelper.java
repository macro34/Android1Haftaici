package com.serifgungor.sqlitedatabase_ornek1.Database;
import com.serifgungor.sqlitedatabase_ornek1.Model.Calisan;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import static android.content.Context.MODE_PRIVATE;

public class DatabaseHelper {
    Context context;
    String dbName;
    SQLiteDatabase db;


    /*
    SQLiteDatabase sınıfı Android'de veritabanı işlemleri için kullanılan sınıftır.


    execSql() -
    - Veri ekleme, Güncelleme ve Silme sorguları yazmak için kullanılır
    insert() -
    - Veri eklemek için kullanılır.
    delete()
    - Veri silmek için kullanılır.
    query()
    - Sorgu göndermek için
    rawQuery
    - insert sorgusundan dönecek değerleri yakalayabilmek için kullanılır.
    - Cursor sınıfı sayesinde dönen değerleri satır satır, kolon değerlerini okuyabiliriz.

    Cursor sınıfı
    - Her bir select sorgusundaki dönen değerleri yakalamız için yardımcı olan sınıftır.
    - Cursor ile kolon ve indis, kolonun değerini yakalayabiliriz.





     */

    public DatabaseHelper(Context context,String dbName){
        this.context = context;
        this.dbName = dbName;
        db = context.openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Calisanlar (id INTEGER PRIMARY KEY AUTOINCREMENT,ad_soyad VARCHAR,ise_giris_tarihi VARCHAR,adresi TEXT,telefon_no VARCHAR)");
    }

    public void calisanEkle(String adSoyad,String iseGirisTarihi, String adres, String telefonNo){
        /*
        StringBuilder sb = new StringBuilder();
        sb.append("insert into Calisanlar(");
        sb.append("ad_soyad,ise_giris_tarihi,adresi,telefon_no) values (");
        sb.append("'"+adSoyad+"',");
        sb.append("'"+iseGirisTarihi+"',");
        sb.append("'"+adres+"',");
        sb.append("'"+telefonNo+"'");
        sb.append(")");
        */

        String sorgu = "insert into Calisanlar(ad_soyad,ise_giris_tarihi,adresi,telefon_no) values ('"+adSoyad+"','"+iseGirisTarihi+"','"+adres+"','"+telefonNo+"')";

        db.execSQL(sorgu);
    }

    public void calisanGuncelle(int calisanId,String adSoyad,String TelNo,String adres){
        db.execSQL("update Calisanlar SET ad_soyad='"+adSoyad+"',telefon_no='"+TelNo+"',adresi='"+adres+"' where id='"+calisanId+"'");
    }

    public  void calisanSil(int calisanId){
        db.execSQL("delete from Calisanlar where id='"+calisanId+"'");
    }

    public Calisan calisaniListele(int calisanId){
        Cursor c = db.rawQuery("Select * from Calisanlar where id="+calisanId,null);
        Calisan calisan=null;
        while (c.moveToNext()){ //Verileri satır satır döndürür.
            //int id, String adSoyad, String iseGirisTarihi, String adresi, String telefonNo

            calisan = new Calisan(
                            c.getInt(c.getColumnIndex("id")),
                            c.getString(c.getColumnIndex("ad_soyad")),
                            c.getString(c.getColumnIndex("ise_giris_tarihi")),
                            c.getString(c.getColumnIndex("adresi")),
                            c.getString(c.getColumnIndex("telefon_no"))
                    );

        }
        return calisan;
    }


    public ArrayList<Calisan> calisanListele(){
        Cursor c = db.rawQuery("Select * from Calisanlar",null);
        ArrayList<Calisan> calisanlar = new ArrayList<>();

        while (c.moveToNext()){ //Verileri satır satır döndürür.
            //int id, String adSoyad, String iseGirisTarihi, String adresi, String telefonNo
            calisanlar.add(
                    new Calisan(
                            c.getInt(c.getColumnIndex("id")),
                            c.getString(c.getColumnIndex("ad_soyad")),
                            c.getString(c.getColumnIndex("ise_giris_tarihi")),
                            c.getString(c.getColumnIndex("adresi")),
                            c.getString(c.getColumnIndex("telefon_no"))
                            )
            );
        }

        /*
        Cursor sınıfı, select sorgusundan dönen değerleri saklar.
        Dönen değerleri okuyabilmek için Cursor sınıfı kullanırız.
         */

        return calisanlar;
    }

}
