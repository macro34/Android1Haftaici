package com.serifgungor.sqlitedatabase_ornek1.Model;

public class Calisan {
    private int id;
    private String adSoyad;
    private String iseGirisTarihi;
    private String adresi;
    private String telefonNo;

    public Calisan(int id, String adSoyad, String iseGirisTarihi, String adresi, String telefonNo) {
        this.id = id;
        this.adSoyad = adSoyad;
        this.iseGirisTarihi = iseGirisTarihi;
        this.adresi = adresi;
        this.telefonNo = telefonNo;
    }

    public Calisan() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getIseGirisTarihi() {
        return iseGirisTarihi;
    }

    public void setIseGirisTarihi(String iseGirisTarihi) {
        this.iseGirisTarihi = iseGirisTarihi;
    }

    public String getAdresi() {
        return adresi;
    }

    public void setAdresi(String adresi) {
        this.adresi = adresi;
    }

    public String getTelefonNo() {
        return telefonNo;
    }

    public void setTelefonNo(String telefonNo) {
        this.telefonNo = telefonNo;
    }
}
