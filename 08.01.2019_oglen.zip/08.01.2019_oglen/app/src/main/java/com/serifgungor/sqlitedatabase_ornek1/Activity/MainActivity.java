package com.serifgungor.sqlitedatabase_ornek1.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.sqlitedatabase_ornek1.Adapter.CalisanlarAdapter;
import com.serifgungor.sqlitedatabase_ornek1.Database.DatabaseHelper;
import com.serifgungor.sqlitedatabase_ornek1.Model.Calisan;
import com.serifgungor.sqlitedatabase_ornek1.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnEkle,btnListele;
    ListView listView;
    DatabaseHelper databaseHelper;
    ArrayList<Calisan> calisanlar;
    CalisanlarAdapter adapter;

    public void calisanDialog(final String islem, final int calisanId){
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog_calisanekle);

        final EditText etAdSoyad = dialog.findViewById(R.id.etAdSoyad);
        final EditText etIseGiris = dialog.findViewById(R.id.etIseGiris);
        final EditText etTelNo = dialog.findViewById(R.id.etTelNo);
        final EditText etAdres = dialog.findViewById(R.id.etAdres);
        Button btnKaydet = dialog.findViewById(R.id.btnKaydet);
        Calisan calisan=null;

        if("ekle".equals(islem)){
            btnKaydet.setText("Çalışanı Ekle");
        }else if("sil".equals(islem)){
            etAdres.setVisibility(View.GONE);
            etAdSoyad.setVisibility(View.GONE);
            etIseGiris.setVisibility(View.GONE);
            etTelNo.setVisibility(View.GONE);
            btnKaydet.setText("Çalışanı Sil");
            /*
            setVisibility metodu içerisindeki
            View.GONE - Nesneyi Kalıcı olarak gizle
            View.VISIBLE - Nesneyi Göster
            View.INVISIBLE - Nesneyi Gizle ama yeri boş kalsın.
             */
        }else if("guncelle".equals(islem)){
            etAdres.setVisibility(View.VISIBLE);
            etAdSoyad.setVisibility(View.VISIBLE);
            etIseGiris.setVisibility(View.VISIBLE);
            etTelNo.setVisibility(View.VISIBLE);
            btnKaydet.setText("Çalışanı Güncelle");
            calisan = databaseHelper.calisaniListele(calisanId);
            etAdres.setText(calisan.getAdresi());
            etAdSoyad.setText(calisan.getAdSoyad());
            etIseGiris.setText(""+calisan.getIseGirisTarihi());
            etTelNo.setText(""+calisan.getTelefonNo());
        }


        btnKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if("ekle".equals(islem)){
                    databaseHelper.calisanEkle(etAdSoyad.getText().toString(),etIseGiris.getText().toString(),etAdres.getText().toString(),etTelNo.getText().toString());
                }else if("sil".equals(islem)){
                    databaseHelper.calisanSil(calisanId);
                }else if("guncelle".equals(islem)){
                    //int calisanId,String adSoyad,String TelNo,String adres
                    databaseHelper.calisanGuncelle(calisanId,etAdSoyad.getText().toString(),etTelNo.getText().toString(),etAdres.getText().toString());
                }
                //Dialoğu kapat
                listeyiGuncelle();
                dialog.dismiss();
            }
        });

        dialog.show();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listViewCalisanlar);
        btnEkle = findViewById(R.id.btnEkle);
        btnListele = findViewById(R.id.btnListele);
        btnEkle.setOnClickListener(this);
        btnListele.setOnClickListener(this);

        //Satıra Tıklama olayı
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {


                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("İşlemi seçiniz");
                adb.setMessage("Lütfen işleminizi seçiniz.");

                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        calisanDialog("guncelle",calisanlar.get(position).getId());
                    }
                });

                adb.setNegativeButton("Vazgeç",null);

                adb.setNeutralButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        calisanDialog("sil",calisanlar.get(position).getId());
                    }
                });

                adb.create();
                adb.show();


            }
        });

        //Veritabanı yardımcı sınıfı çağırdık
        databaseHelper = new DatabaseHelper(getApplicationContext(),"myDB");
        //Arraylist içerisine değerleri databaseHelper'dan çağırdık
        calisanlar = databaseHelper.calisanListele();
        //adapter'a verileri arraylist çalışanlardan aldık
        adapter = new CalisanlarAdapter(getApplicationContext(),calisanlar);
        //Listview'a verileri veritabanından yüklemiş olduk
        listView.setAdapter(adapter);


    }


    public void listeyiGuncelle(){
        calisanlar = databaseHelper.calisanListele();
        adapter = new CalisanlarAdapter(getApplicationContext(),calisanlar);
        adapter.notifyDataSetChanged();
        listView.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.btnEkle){
            calisanDialog("ekle",0);
        }else if(v.getId()==R.id.btnListele){
            listeyiGuncelle();
        }
    }
}
