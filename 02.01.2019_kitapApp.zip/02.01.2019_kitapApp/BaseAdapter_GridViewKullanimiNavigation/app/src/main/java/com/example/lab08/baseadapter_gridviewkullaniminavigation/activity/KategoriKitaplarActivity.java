package com.example.lab08.baseadapter_gridviewkullaniminavigation.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.lab08.baseadapter_gridviewkullaniminavigation.R;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.adapter.KategoriKitaplarAdapter;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kategori;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kitap;

import java.util.ArrayList;

public class KategoriKitaplarActivity extends AppCompatActivity {

    KategoriKitaplarAdapter adapter;
    ArrayList<Kitap> kitaplar;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori_kitaplar);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        kitaplar = new ArrayList<>();

        //int kitapId, String ad, String kategori, String yazarAdSoyad, String yayinEvi, String aciklama, int sayfaSayisi, int ilkBasimYili, int resim
        kitaplar.add(new Kitap(1, "Kitap Adi 1", "Kategori 1", "Yazar Ad Soyad 1", "Yayin Evi 1",
                "Aciklama 1", 100, 2000, R.drawable.cardview_bg_01));
        kitaplar.add(new Kitap(2, "Kitap Adi 2", "Kategori 2", "Yazar Ad Soyad 2", "Yayin Evi 2",
                "Aciklama 2", 200, 2001, R.drawable.cardview_bg_02));
        kitaplar.add(new Kitap(3, "Kitap Adi 3", "Kategori 3", "Yazar Ad Soyad 3", "Yayin Evi 3",
                "Aciklama 3", 300, 2002, R.drawable.cardview_bg_03));
        kitaplar.add(new Kitap(4, "Kitap Adi 4", "Kategori 4", "Yazar Ad Soyad 4", "Yayin Evi 4",
                "Aciklama 4", 400, 2003, R.drawable.cardview_bg_04));
        kitaplar.add(new Kitap(5, "Kitap Adi 5", "Kategori 5", "Yazar Ad Soyad 5", "Yayin Evi 5",
                "Aciklama 5", 500, 2004, R.drawable.cardview_bg_05));
        kitaplar.add(new Kitap(6, "Kitap Adi 6", "Kategori 6", "Yazar Ad Soyad 6", "Yayin Evi 6",
                "Aciklama 6", 600, 2005, R.drawable.cardview_bg_06));
        kitaplar.add(new Kitap(7, "Kitap Adi 7", "Kategori 7", "Yazar Ad Soyad 7", "Yayin Evi 7",
                "Aciklama 7", 700, 2006, R.drawable.cardview_bg_07));
        kitaplar.add(new Kitap(8, "Kitap Adi 8", "Kategori 8", "Yazar Ad Soyad 8", "Yayin Evi 8",
                "Aciklama 8", 800, 2007, R.drawable.cardview_bg_08));

        adapter = new KategoriKitaplarAdapter(kitaplar, getApplicationContext());
        listView = findViewById(R.id.listViewKategoriKitaplar);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
