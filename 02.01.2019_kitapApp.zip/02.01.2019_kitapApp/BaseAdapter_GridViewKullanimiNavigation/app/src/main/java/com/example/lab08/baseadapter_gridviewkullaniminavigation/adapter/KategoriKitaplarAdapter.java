package com.example.lab08.baseadapter_gridviewkullaniminavigation.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadapter_gridviewkullaniminavigation.R;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.activity.KitapDetayActivity;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kitap;

import java.util.ArrayList;

public class KategoriKitaplarAdapter extends BaseAdapter {
    ArrayList<Kitap> kitaplar;
    Context context;
    LayoutInflater layoutInflater;

    public KategoriKitaplarAdapter (ArrayList<Kitap> kitaplar, Context context) {
        this.kitaplar = kitaplar;
        this.context = context;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kitaplar.size();
    }

    @Override
    public Object getItem(int position) {
        return kitaplar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final View v = layoutInflater.inflate(R.layout.custom_listview_kategorikitaplar, null);

        ImageView ivResim = v.findViewById(R.id.ivKategoriKitap);
        TextView tvAd, tvYazar, tvKategori, tvYayinEvi, tvIlkBasimTarihi;

        tvAd = v.findViewById(R.id.tvKategoriKitapAdi);
        tvYazar = v.findViewById(R.id.tvKategoriKitapYazari);
        tvKategori = v.findViewById(R.id.tvKategoriKitapKategorisi);
        tvYayinEvi = v.findViewById(R.id.tvKategoriKitapYayinEvi);
        tvIlkBasimTarihi = v.findViewById(R.id.tvKategoriKitapIlkBasimTarihi);

        ivResim.setImageResource(kitaplar.get(position).getResim());
        tvAd.setText(""+kitaplar.get(position).getAd());
        tvIlkBasimTarihi.setText(""+kitaplar.get(position).getIlkBasimYili());
        tvKategori.setText(""+kitaplar.get(position).getKategori());
        tvYazar.setText(""+kitaplar.get(position).getYazarAdSoyad());
        tvYayinEvi.setText(""+kitaplar.get(position).getYayinEvi());

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), KitapDetayActivity.class);
                intent.putExtra("detay", kitaplar.get(position));
                v.getContext().startActivity(intent);
            }
        });

        return v;
    }
}
