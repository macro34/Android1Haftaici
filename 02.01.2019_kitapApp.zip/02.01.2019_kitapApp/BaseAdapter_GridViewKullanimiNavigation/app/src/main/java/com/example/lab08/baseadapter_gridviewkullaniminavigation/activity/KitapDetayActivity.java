package com.example.lab08.baseadapter_gridviewkullaniminavigation.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadapter_gridviewkullaniminavigation.R;
import com.example.lab08.baseadapter_gridviewkullaniminavigation.model.Kitap;

public class KitapDetayActivity extends AppCompatActivity {

    TextView tvKitapAdi, tvAciklama;
    ImageView ivResim;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitap_detay);

        Kitap kitap = (Kitap) getIntent().getSerializableExtra("detay");
        setTitle(kitap.getAd());

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ivResim = findViewById(R.id.ivKitapDetay);
        tvKitapAdi = findViewById(R.id.tvKitapDetayBaslik);
        tvAciklama = findViewById(R.id.tvKitapDetayIcerik);
        btn = findViewById(R.id.btnKitapDetayPdf);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ivResim.setImageResource(kitap.getResim());
        tvKitapAdi.setText(""+kitap.getAd());
        tvAciklama.setText(kitap.getAciklama());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
