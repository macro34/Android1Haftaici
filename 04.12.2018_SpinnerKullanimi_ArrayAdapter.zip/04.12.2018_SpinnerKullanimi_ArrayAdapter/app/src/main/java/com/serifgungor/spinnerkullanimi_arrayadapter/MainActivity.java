package com.serifgungor.spinnerkullanimi_arrayadapter;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    LinearLayout linearLayout;
    ArrayAdapter<String> adapter;
    String[] urunler = {"Android Telefon","Macbook Pro","Laptop","Smart TV"};

    public void butonOlustur(String yazi){
        Button btn = new Button(getApplicationContext());
        btn.setText(yazi);
        linearLayout.addView(btn);
    }

    public void yaziOlustur(String yazi){
        TextView tv = new TextView(getApplicationContext());
        tv.setTextSize(24f);
        tv.setTextColor(Color.RED);
        tv.setText(yazi);
        linearLayout.addView(tv);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,urunler);
        spinner = findViewById(R.id.spinner);
        linearLayout = findViewById(R.id.linearLayout);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                yaziOlustur(urunler[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}
