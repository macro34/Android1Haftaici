package com.serifgungor.baseadapterkullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.serifgungor.baseadapterkullanimi.Adapter.DersAdapter;
import com.serifgungor.baseadapterkullanimi.Model.Ders;
import com.serifgungor.baseadapterkullanimi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listViewDersler;
    DersAdapter adapter;
    ArrayList<Ders> dersler = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewDersler = findViewById(R.id.listViewDersler);
        dersler.add(new Ders("Türkçe","http://serifgungor.com/content/uploads/images/0218/android-picasso-glide-kutuphanesi-kullanimi-karsilastirma.jpg"));
        dersler.add(new Ders("Bilgisayar","http://serifgungor.com/content/uploads/images/0918/android-application-katmani-kullanimi.jpg"));
        dersler.add(new Ders("İngilizce","http://serifgungor.com/content/uploads/images/0918/android-activity-lifecycle-metotlari.jpg"));
        dersler.add(new Ders("Matematik","http://serifgungor.com/content/uploads/images/1017/android_dersleri.jpg"));
        dersler.add(new Ders("Resim","http://serifgungor.com/content/uploads/images/0716/visual-studio-csharp-sqlite-kurulumu-ve-kullanimi.jpg"));

        adapter = new DersAdapter(dersler,this);
        listViewDersler.setAdapter(adapter);
        listViewDersler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),dersler.get(position).getDersAdi(),Toast.LENGTH_SHORT).show();
            }
        });

    }
}
