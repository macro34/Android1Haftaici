package com.serifgungor.baseadapterkullanimi.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.baseadapterkullanimi.Model.Ders;
import com.serifgungor.baseadapterkullanimi.R;

import java.util.ArrayList;

public class DersAdapter extends BaseAdapter {

    ArrayList<Ders> dersler;
    LayoutInflater layoutInflater;
    public DersAdapter(){

    }
    public DersAdapter(ArrayList<Ders> dersler, Activity activity){
        this.dersler = dersler;
        this.layoutInflater =
                (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dersler.size();
    }

    @Override
    public Object getItem(int position) {
        return dersler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.ders_satir_goruntusu,null);
        ImageView iv = v.findViewById(R.id.ivResim);
        TextView tv = v.findViewById(R.id.tvBaslik);

        tv.setText(dersler.get(position).getDersAdi());
        Glide.with(v.getContext()).load(dersler.get(position).getDersResim()).into(iv);

        return v;
    }
}
