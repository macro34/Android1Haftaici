package com.serifgungor.baseadapterkullanimi.Model;

public class Ders {
    private String dersAdi;
    private String dersResim;

    public Ders() {
    }

    public Ders(String dersAdi, String dersResim) {
        this.dersAdi = dersAdi;
        this.dersResim = dersResim;
    }

    public String getDersAdi() {
        return dersAdi;
    }

    public void setDersAdi(String dersAdi) {
        this.dersAdi = dersAdi;
    }

    public String getDersResim() {
        return dersResim;
    }

    public void setDersResim(String dersResim) {
        this.dersResim = dersResim;
    }
}
